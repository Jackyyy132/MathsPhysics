
package snookercoursework;

/**
 *
 * @author w1546167
 */
public class Point2D {
    
}
