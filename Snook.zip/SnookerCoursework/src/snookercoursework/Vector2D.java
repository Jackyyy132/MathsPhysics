/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snookercoursework;

/**
 *
 * @author w1546167
 */
public class Vector2D {
    
    public float x = 0.0f;
    public float y = 0.0f;
    
    public Vector2D(){
        
    }
    
    public Vector2D(float x, float y){
        this.x = x;
        this.y = y;
    }
    
}
