/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snookercoursework;

/**
 *
 * @author w1546167
 */
public class Vector3D {
        
    public float x = 0.0f;
    public float y = 0.0f;
    public float z = 0.0f;
    
    public Vector3D(){
        
    }
    
    public Vector3D(float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
